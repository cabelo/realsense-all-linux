/* License: Apache 2.0. See LICENSE file in root directory.
   Copyright(c) 2017 Intel Corporation. All Rights Reserved. */

#pragma once

#define D4XX_RECOMMENDED_FIRMWARE_VERSION "5.12.2.100"
#define SR3XX_RECOMMENDED_FIRMWARE_VERSION "3.26.1.0"
#define D4XX_RC_FIRMWARE_VERSION "5.12.2.100"
#define T26X_FIRMWARE_VERSION "0.2.0.926"
